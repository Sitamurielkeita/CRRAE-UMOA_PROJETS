# 🚀 Projet Hello GitHub

Projet Python pour apprendre **Git & GitHub** :
- Branches, commits, PR
- Issues et gestion de conflits
- GitHub Actions pour les tests

## ⚡ Installation
```bash
git clone https://github.com/<ton-compte>/HelloGithub.git
cd HelloGitHub
pip install -r requirements.txt
